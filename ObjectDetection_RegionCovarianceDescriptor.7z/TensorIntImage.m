function P = TensorIntImage(F)

F = permute(F,[3 1 2]);

[d,h,w] = size(F);

P = int64(zeros(d,h+1,w+1));
for i=1:d
    P(i,:,:) = integralImage(squeeze(int64(F(i,:,:))));
end
P = P(:,2:end,2:end);

end