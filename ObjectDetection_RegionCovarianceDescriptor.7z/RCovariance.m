function Cr = RCovariance(P,Q,yp,xp,ypp,xpp)

Rq = Q(:,:,ypp,xpp) + Q(:,:,yp,xp) - Q(:,:,ypp,xp) - Q(:,:,yp,xpp);
Rp = P(:,ypp,xpp) + P(:,yp,xp) - P(:,ypp,xp) - P(:,yp,xpp);

n = (ypp - yp)*(xpp - xp);

Cr = 1/(n - 1) * (double(Rq) - (1/n) * double(Rp.*Rp'));

end