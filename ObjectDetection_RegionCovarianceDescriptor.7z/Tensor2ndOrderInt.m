function Q = Tensor2ndOrderInt(F)

F = permute(F,[3 1 2]);

[d,h,w] = size(F);

F2 = int64(zeros(d,d,h,w));
for i=1:d
    for j=1:d
        F2(i,j,:,:) = F(i,:,:).*F(j,:,:);
    end
end
Q = int64(zeros(d,d,h+1,w+1));
for i=1:d
    for j=1:d
        Q(i,j,:,:) = integralImage(squeeze(F2(i,j,:,:)));
    end
end
Q = Q(:,:,2:end,2:end);

end