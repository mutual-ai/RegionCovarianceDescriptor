function [BM, Cz] = NearestNeigborSearch(Co1,Pt,Qt,ho,wo)

scales = zeros(9,2);

[~,h,w] = size(Pt);

BM = zeros(1,5);

if ho == min(ho,wo)
  ratio = double(wo/ho);
  for j = 1:9
  scales(j,:) = [j*floor(h/9) j*floor(ratio*h/9)];
  end
elseif wo == min(ho,wo)
  ratio = double(ho/wo);
  for j = 1:9
  scales(j,:) = [j*floor(ratio*w/9) j*floor(w/9)];
  end
end

i = 1;

for s = 1:9;
  
  hl = scales(s,1);
  wl = scales(s,2);
  hs = 1;
  while (hs <= (h - hl))
    ws = 1;
    while (ws <= (w - wl))
      C = RCovariance(Pt,Qt,hs,ws,(hs+hl),(ws+wl));
      Cz(i,:,:) = C;
      d = CovarianceDistance(Co1,C);
      BM(i,:) = [hs ws (hs+hl) (ws+wl) d];
      i = i + 1;    
      ws = ws + 5;
    end
    hs = hs + 5;
  end
end



